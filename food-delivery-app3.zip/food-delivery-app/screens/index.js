import Home from './Home'
import Restaurant from './Restaurant'
import OrderDelivery from './OrderDelivery'

export {
    Home,
    Restaurant,
    OrderDelivery
}